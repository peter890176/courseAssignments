package betterpizza;

import java.util.HashMap;
import java.util.Map;

import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

/**
 * This class represents a cheese pizza.
 */
public class CheesePizza extends AlaCartePizza {

  /**
   * This is an inner builder class to build Cheese Pizza.
   */
  public static class CheesePizzaBuilder extends PizzaBuilder<CheesePizza.CheesePizzaBuilder> {

    /**
     * This is the construct for inner builder class to build Cheese Pizza.
     */
    public CheesePizzaBuilder() {
      new AlaCartePizza.AlaCartePizzaBuilder();
      this.toppings = new HashMap<>();
      this.toppings.put(ToppingName.Cheese, ToppingPortion.Full);
      this.toppings.put(ToppingName.Sauce, ToppingPortion.Full);
    }

    protected CheesePizzaBuilder returnBuilder() {
      return this;
    }

    public CheesePizzaBuilder crust(Crust crust) {
      this.crust = crust;
      return returnBuilder();
    }

    public CheesePizzaBuilder size(Size size) {
      this.size = size;
      return returnBuilder();
    }

    /**
     * To get rid of cheese.
     */
    public CheesePizzaBuilder noCheese() {
      this.toppings.remove(ToppingName.Cheese);
      return returnBuilder();
    }

    /**
     * To set left half of cheese.
     */
    public CheesePizzaBuilder leftHalfCheese() {
      this.toppings.remove(ToppingName.Cheese);
      this.toppings.put(ToppingName.Cheese, ToppingPortion.LeftHalf);
      return returnBuilder();
    }

    /**
     * To set right half of cheese.
     */
    public CheesePizzaBuilder rightHalfCheese() {
      this.toppings.remove(ToppingName.Cheese);
      this.toppings.put(ToppingName.Cheese, ToppingPortion.RightHalf);
      return returnBuilder();
    }

    /**
     * To add toppings.
     */
    public CheesePizzaBuilder addTopping(ToppingName name, ToppingPortion portion) {
      this.toppings.put(name, portion);
      return returnBuilder();
    }

    /**
     * To remove toppings.
     */
    public CheesePizzaBuilder removeTopping(ToppingName name) {
      this.toppings.remove(name);
      return returnBuilder();
    }

    public CheesePizza build() {
      return new CheesePizza(size, crust, toppings);
    }
  }

  /**
   * Create a pizza given its crust type, size and toppings.
   */
  protected CheesePizza(Size size, Crust crust, Map<ToppingName, ToppingPortion> toppings)
          throws IllegalStateException {
    super(size, crust, toppings);

  }
}
