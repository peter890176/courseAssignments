/**
 * This class describes the attributes and functions of chess piece called Knight.
 * Many of the attributes and functions have already been defined in the AbstractChess class.
 */
public class Knight extends AbstractChess {
  /**
   * The position and color are given to the constructor in the abstract class.
   * It helps the construction of this Knight chess piece.
   *
   * @param row   represents the row location for the Knight.
   * @param col   represents the col location for the Knight.
   * @param color represents the of the chess piece.
   */
  public Knight(int row, int col, Color color) {
    super(row, col, color);
  }

  /**
   * This method is checking the location is available for the chess piece Knight, and return.
   *
   * @param row represents the row location for the next move.
   * @param col represents the col location for the next move.
   */
  @Override
  public boolean canMove(int row, int col) {
    if ((row < 0) || (col < 0) || (row >= 8) || (col >= 8)) {
      return false;
    }
    return (Math.abs(row - this.row) == 1 && Math.abs(col - this.col) == 2)
            || (Math.abs(col - this.col) == 1 && Math.abs(row - this.row) == 2);
  }
}
