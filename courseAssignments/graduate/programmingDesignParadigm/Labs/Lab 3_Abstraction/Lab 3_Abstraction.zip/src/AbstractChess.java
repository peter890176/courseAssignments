/**
 * This abstract class is to reduce redundant methods and attributes, thus minimize the code.
 */
public abstract class AbstractChess implements ChessPiece {
  protected int row;
  protected int col;
  protected Color color;

  protected AbstractChess(int row, int col, Color color) throws IllegalArgumentException {
    if ((row < 0) || (col < 0)) {
      throw new IllegalArgumentException("Illegal position");
    }
    this.row = row;
    this.col = col;
    this.color = color;
  }

  /**
   * This method is checking the location is available for the chess.
   *
   * @param row represents the location that the chess piece can be moved
   * @param col represents the location that the chess piece can be moved
   */
  public abstract boolean canMove(int row, int col);

  /**
   * This method return the row position of the chess.
   */
  public int getRow() {
    return row;
  }

  /**
   * This method return the column position of the chess.
   */
  public int getColumn() {
    return col;
  }

  /**
   * This method return the color type of the chess.
   */
  public Color getColor() {
    return color;
  }

  /**
   * This method is checking the chess is available for this chess to kill.
   *
   * @param piece represents the other chess piece that this should be killed by this chess piece.
   */
  public boolean canKill(ChessPiece piece) {
    return (this.getColor() != piece.getColor()) && canMove(
            piece.getRow(),
            piece.getColumn());
  }
}
