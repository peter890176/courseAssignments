import org.junit.Test;

import static org.junit.Assert.assertFalse;

/**
 * This is a test class to test emergency method.
 */
public class PatientMonitorTest {

  /**
   * This test is to test the malfunction emergency method.
   */
  @Test
  public void testEmergency() {
    PatientMonitor m = new PatientMonitor();
    SingleBloodPressureRecord recA = new SingleBloodPressureRecord("aaa", 150, 130);
    SingleBloodPressureRecord recB = new SingleBloodPressureRecord("bbb", 170, 130);
    SingleBloodPressureRecord recC = new SingleBloodPressureRecord("ccc", 150, 140);
    m.add(recA);
    m.add(recB);
    m.add(recC);
    assertFalse(m.emergency());
  }


}