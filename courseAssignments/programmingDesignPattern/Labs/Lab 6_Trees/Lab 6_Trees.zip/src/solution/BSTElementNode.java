package solution;

import java.util.function.Consumer;

/**
 * This class represents a data-containing node of the binary search tree.
 * It mutates on all relevant operations.
 */
public class BSTElementNode<T extends Comparable<T>> implements BSTNode<T> {
  private BSTNode<T> left;
  private BSTNode<T> right;
  private T data;

  /**
   * This constructor is to build a non-leaf node.
   */
  public BSTElementNode(T data, BSTNode<T> left, BSTNode<T> right) {
    this.data = data;
    this.left = left;
    this.right = right;
  }

  /**
   * This method is to build insert data into a non-leaf node.
   */
  @Override
  public BSTNode insert(T data) {
    if (data.compareTo(this.data) < 0) {
      this.left = this.left.insert(data);
    } else if (data.compareTo(this.data) > 0) {
      this.right = this.right.insert(data);
    }
    return this;
  }

  /**
   * This method is to find the minimum of this subtree.
   */
  @Override
  public T minimum() {
    T minimum;

    try {
      minimum = this.left.minimum();
    } catch (NothingThereException e) {
      minimum = this.data;
    }
    return minimum;
  }

  /**
   * This method is to find the maximum of this subtree.
   */
  @Override
  public T maximum() {
    T maximum;

    try {
      maximum = this.right.maximum();
    } catch (NothingThereException e) {
      maximum = this.data;
    }

    return maximum;
  }

  /**
   * This method is to check the data in this node.
   */
  @Override
  public boolean contains(T data) {
    int compareResult = data.compareTo(this.data);

    if (compareResult == 0) {
      return true;
    } else if (compareResult < 0) {
      return this.left.contains(data);
    } else {
      return this.right.contains(data);
    }
  }

  /**
   * This method is to convert the data of this subtree.
   */
  @Override
  public String toString() {
    String left;
    String right;
    String middle;
    middle = this.data.toString();
    left = this.left.toString();
    right = this.right.toString();
    if (left.length() > 0) {
      left = left + " ";
    }
    if (right.length() > 0) {
      right = " " + right;
    }
    return left + middle + right;
  }

  /**
   * This method is to traverse this subtree in preorder order.
   */
  @Override
  public void preorder(Consumer<T> consumer) {
    if (this != null) {
      consumer.accept(this.data);
    }
    if (this.left != null) {
      this.left.preorder(consumer);
    }
    if (this.right != null) {
      this.right.preorder(consumer);
    }
  }

  /**
   * This method is to traverse this subtree in postorder order.
   */
  @Override
  public void postorder(Consumer<T> consumer) {
    if (this.left != null) {
      this.left.postorder(consumer);
    }
    if (this.right != null) {
      this.right.postorder(consumer);
    }
    consumer.accept(this.data);
  }

  /**
   * This method is to copy this subtree.
   */
  @Override
  public BSTNode<T> copy() {
    BSTElementNode<T> newElementNode = new BSTElementNode<T>(data, this, this);
    if (this.left != null) {
      newElementNode.left = this.left.copy();
    }
    if (this.right != null) {
      newElementNode.right = this.right.copy();
    }
    return newElementNode;
  }

  /**
   * This method is to check the sameness of this subtree.
   */
  @Override
  public boolean same(BSTNode<T> other) {
    if (other instanceof BSTEmptyNode) {
      return false;
    }
    if (this.data != ((BSTElementNode) other).data) {
      return false;
    }
    boolean leftNodeSameness = this.left.same(((BSTElementNode) other).left);
    boolean rightNodeSameness = this.right.same(((BSTElementNode) other).right);
    return leftNodeSameness && rightNodeSameness;
  }
}
