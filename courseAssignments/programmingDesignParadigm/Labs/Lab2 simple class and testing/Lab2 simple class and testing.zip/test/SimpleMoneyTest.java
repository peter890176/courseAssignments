import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * This is the test class created by Yue Wen Peter Li, and in order to test the class SimpleBoxSet.
 */
public class SimpleMoneyTest {

  /**
   * To test the constructor is created successful or not in simple case.
   */
  @Test
  public void testForConstructor() {
    SimpleMoney money = new SimpleMoney(100, 20);
    double d = money.getDecimalValue();
    assertEquals(d, 100.20, 0.005);
  }

  /**
   * To test the constructor could handle cent >0.99 case.
   */
  @Test
  public void testForConstructorCentOver99() {
    SimpleMoney money = new SimpleMoney(100, 105);
    double d = money.getDecimalValue();
    assertEquals(d, 101.05, 0.005);
  }

  /**
   * To test the negative dollars for constructor should throw exception.
   */
  @Test
  public void testConstructorWithNegativeDollarsShouldThrow() {
    for (int i = 0; i < 10000; i++) {
      try {
        SimpleMoney money = new SimpleMoney(-i - 1, 20);
        fail("the negative parameter in constructor should throw exception");
      } catch (IllegalArgumentException e) {
        continue;
      }
    }
  }

  /**
   * To test the negative cents for constructor should throw exception.
   */
  @Test
  public void testConstructorWithNegativeCentsShouldThrow() {
    for (int i = 0; i < 10000; i++) {
      try {
        SimpleMoney money = new SimpleMoney(20, -i - 1);
        fail("the negative parameter in constructor should throw exception");
      } catch (IllegalArgumentException e) {
        continue;
      }
    }
  }

  /**
   * To test zero dollar should be successfully constructed.
   */
  @Test
  public void testConstructorWithZeroDollars() {
    SimpleMoney money = new SimpleMoney(0, 20);
    double d = money.getDecimalValue();
    assertEquals(d, 0.20, 0.005);
  }

  /**
   * To test zero cent should be successfully constructed.
   */
  @Test
  public void testConstructorWithZeroCents() {
    SimpleMoney money = new SimpleMoney(100, 0);
    double d = money.getDecimalValue();
    assertEquals(d, 100.00, 0.005);
  }

  /**
   * To test the GetDecimal() is correct or not.
   */
  @Test
  public void testGetDecimalValue() {
    Money money = new SimpleMoney(100, 10);
    double d = money.getDecimalValue();
    assertEquals(d, 100.10, 0.005);
  }

  /**
   * To test the GetDecimal() is correct in cent over 99 case.
   */
  @Test
  public void testGetDecimalValueCentOver99() {
    Money money = new SimpleMoney(100, 110);
    double d = money.getDecimalValue();
    assertEquals(d, 101.10, 0.005);
  }

  /**
   * To test the GetDecimal() is correct or not in zero dollar.
   */
  @Test
  public void testGetDecimalValueInZeroDollar() {
    Money money = new SimpleMoney(0, 10);
    double d = money.getDecimalValue();
    assertEquals(d, 0.10, 0.005);
  }

  /**
   * To test the GetDecimal() is correct or not in zero cent.
   */
  @Test
  public void testGetDecimalValueInZeroCent() {
    Money money = new SimpleMoney(100, 0);
    double d = money.getDecimalValue();
    assertEquals(d, 100.00, 0.005);
  }

  /**
   * To test the ToString() is correct or not.
   */
  @Test
  public void testToString() {
    Money money = new SimpleMoney(100, 10);
    String s = "$100.10";
    String money_S = money.toString();
    assertEquals(s, money_S);
  }

  /**
   * To test the ToString() is correct or not in cent over 99 case.
   */
  @Test
  public void testToStringCentOver99() {
    Money money = new SimpleMoney(100, 110);
    String s = "$101.10";
    String money_S = money.toString();
    assertEquals(s, money_S);
  }

  /**
   * To test the ToString() format is correct for last digit of cent is 0.
   */
  @Test
  public void testToStringLastDigitZero() {
    Money money = new SimpleMoney(100, 10);
    String s = "$100.10";
    String money_S = money.toString();
    assertEquals(s, money_S);
  }

  /**
   * To test the ToString() format is correct for the tenth after point is zero.
   */
  @Test
  public void testToStringTehthIsZero() {
    Money money = new SimpleMoney(100, 5);
    String s = "$100.05";
    String money_S = money.toString();
    assertEquals(s, money_S);
  }
  
  /**
   * To test the ToString() format is correct for while dollars is less than ten.
   */
  @Test
  public void testToStringLessThanTen() {
    Money money = new SimpleMoney(9, 5);
    String s = "$9.05";
    String money_S = money.toString();
    assertEquals(s, money_S);
  }

  /**
   * To test the ToString() is correct or not in 0 dollar.
   */
  @Test
  public void testToStringInZeroDollar() {
    Money money = new SimpleMoney(0, 10);
    String s = "$0.10";
    String money_S = money.toString();
    assertEquals(s, money_S);
  }

  /**
   * To test the ToString() is correct or not in 0 dollar.
   */
  @Test
  public void testToStringInZeroCent() {
    Money money = new SimpleMoney(100, 0);
    String s = "$100.00";
    String money_S = money.toString();
    assertEquals(s, money_S);
  }


  /**
   * To test the add(Money other) is successful or not.
   */
  @Test
  public void testAddForOneParameter() {
    Money money_a = new SimpleMoney(100, 10);
    Money money_b = new SimpleMoney(50, 50);
    money_a.add(money_b);
    double d = money_a.getDecimalValue();
    assertEquals(d, 150.60, 0.005);
  }


  /**
   * To test the add(int Dollars, int Cents) method is operated successfully or not.
   */
  @Test
  public void testAddTwoParameters() {
    Money money_a = new SimpleMoney(100, 10);
    money_a.add(10, 10);
    double d = money_a.getDecimalValue();
    assertEquals(d, 110.20, 0.005);
  }

  /**
   * Test if the dollars is negative, add(int Dollars, int Cents) method should throw exception.
   */
  @Test
  public void testAddTwoParametersWithNegativeDollars() {
    for (int i = 0; i < 10000; i++) {
      try {
        SimpleMoney money = new SimpleMoney(100, 10);
        money.add(-i - 1, 10);
        fail("the negative parameter in constructor should throw exception");
      } catch (IllegalArgumentException e) {
        continue;
      }
    }
  }

  /**
   * Test if the cents is negative, add(int Dollars, int Cents) method should throw exception.
   */
  @Test
  public void testAddTwoParametersWithNegativeCents() {
    for (int i = 0; i < 10000; i++) {
      try {
        SimpleMoney money = new SimpleMoney(100, 10);
        money.add(10, -i - 1);
        fail("the negative parameter in constructor should throw exception");
      } catch (IllegalArgumentException e) {
        continue;
      }
    }
  }
}