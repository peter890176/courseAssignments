import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

/**
 * This test class is to test the functionalities of the device.
 */

public class SingleBloodPressureRecordTest {

  /**
   * This method should return correct ID.
   */
  @org.junit.Test
  public void getID() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    String s = rec.getID();
    assertEquals("aaa", s);
  }

  /**
   * This method should return correct systolic reading.
   */
  @org.junit.Test
  public void getSystolicReading() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    int t = (int) rec.getDiastolicReading();
    assertEquals(10, t);
  }

  /**
   * This method should return correct systolic reading.
   */
  @org.junit.Test
  public void getDiastolicReading() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    int t = (int) rec.getDiastolicReading();
    assertEquals(10, t);
  }

  /**
   * This method should update a new systolic reading into the sys.
   */
  @org.junit.Test
  public void updateSystolicReading() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    rec.updateSystolicReading(20);
    int t = (int) rec.getSystolicReading();
    assertEquals(20, t);
  }

  /**
   * This method should update a new diastolic reading into the dias.
   */
  @org.junit.Test
  public void updateDiastolicReading() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    rec.updateDiastolicReading(20);
    int t = (int) rec.getDiastolicReading();
    assertEquals(20, t);
  }



  /*
  @org.junit.Test
  public void testEqual() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    SingleBloodPressureRecord cer = new SingleBloodPressureRecord("aaa", 10, 10);
    assertTrue(rec.equals(cer));
  }

  @org.junit.Test
  public void testEqualDiff() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    SingleBloodPressureRecord cer = new SingleBloodPressureRecord("aaa", 10.9, 9.1);
    assertTrue(rec.equals(cer));
  }

  @org.junit.Test
  public void testHash() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    SingleBloodPressureRecord cer = new SingleBloodPressureRecord("aaa", 10.9, 9.1);
    int a = rec.hashCode();
    int b = cer.hashCode();
    assertEquals(a, b);
  }
  */


  /**
   * To test the equal method overrides successful or not in same value.
   */
  @org.junit.Test
  public void testEqual() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    SingleBloodPressureRecord cer = new SingleBloodPressureRecord("aaa", 10, 10);
    assertTrue(rec.equals(cer));
  }

  /**
   * To test the equal method overrides successful or not in slight differences.
   */
  @org.junit.Test
  public void testEqualDiff() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    SingleBloodPressureRecord cer = new SingleBloodPressureRecord("aaa", 10.4, 9.5);
    assertTrue(rec.equals(cer));
  }

  /**
   * To test the hash method overrides successful or not.
   */
  @org.junit.Test
  public void testHash() {
    SingleBloodPressureRecord rec = new SingleBloodPressureRecord("aaa", 10, 10);
    SingleBloodPressureRecord cer = new SingleBloodPressureRecord("aaa", 10.4, 9.5);
    int a = rec.hashCode();
    int b = cer.hashCode();
    assertEquals(a, b);
  }
}
