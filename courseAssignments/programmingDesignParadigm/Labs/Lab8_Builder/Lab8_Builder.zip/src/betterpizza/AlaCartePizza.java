package betterpizza;

import java.util.HashMap;
import java.util.Map;

import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

/**
 * This class represents an ala carte pizza (i.e. a pizza that can
 * have an arbitrary number of ingredients.)
 */
public class AlaCartePizza extends PizzaBuilder<AlaCartePizza.AlaCartePizzaBuilder>
        implements ObservablePizza {

  /**
   * This is an inner builder class to build AlaCarte Pizza.
   */
  public static class AlaCartePizzaBuilder extends PizzaBuilder<AlaCartePizzaBuilder> {
    protected Crust crust;
    protected Size size;
    protected Map<ToppingName, ToppingPortion> toppings;


    public AlaCartePizzaBuilder() {
      this.toppings = new HashMap<>();
    }

    public AlaCartePizzaBuilder crust(Crust crust) {
      this.crust = crust;
      return returnBuilder();
    }

    public AlaCartePizzaBuilder size(Size size) {
      this.size = size;
      return returnBuilder();
    }

    public AlaCartePizzaBuilder addTopping(ToppingName name, ToppingPortion portion) {
      this.toppings.put(name, portion);
      return returnBuilder();
    }

    public AlaCartePizzaBuilder removeTopping(ToppingName name) {
      this.toppings.remove(name);
      return returnBuilder();
    }

    public AlaCartePizza build() {
      return new AlaCartePizza(size, crust, toppings);
    }
  }


  /**
   * Create a pizza given its crust type, size and toppings.
   */
  protected AlaCartePizza(Size size, Crust crust, Map<ToppingName, ToppingPortion> toppings)
          throws IllegalStateException {
    if (size == null || crust == null) {
      throw new IllegalStateException();
    }
    this.crust = crust;
    this.size = size;
    this.toppings = toppings;
  }


  public ToppingPortion hasTopping(ToppingName name) {
    return this.toppings.getOrDefault(name, null);
  }

  /**
   * To calculate the total cost.
   */
  public double cost() {
    double cost = 0.0;
    for (Map.Entry<ToppingName, ToppingPortion> item : this.toppings.entrySet()) {
      cost += item.getKey().getCost() * item.getValue().getCostMultiplier();
    }
    return cost + this.size.getBaseCost();
  }
}
