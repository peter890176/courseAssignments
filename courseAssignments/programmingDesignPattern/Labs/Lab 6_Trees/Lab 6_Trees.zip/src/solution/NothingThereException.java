package solution;

/**
 * This class is dealing with the runtime exception.
 */
public class NothingThereException extends RuntimeException {

  public NothingThereException(String message) {
    super(message);
  }

}
