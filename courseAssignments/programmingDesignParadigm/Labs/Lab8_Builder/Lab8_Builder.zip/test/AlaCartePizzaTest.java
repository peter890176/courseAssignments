import org.junit.Before;
import org.junit.Test;

import betterpizza.AlaCartePizza;
import betterpizza.ObservablePizza;
import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

import static org.junit.Assert.assertEquals;

/**
 * This is the test class for AlaCarte Pizza.
 */
public class AlaCartePizzaTest {
  private ObservablePizza alacarte;

  @Before
  public void setup() {
    alacarte = new AlaCartePizza.AlaCartePizzaBuilder()
            .crust(Crust.Classic)
            .size(Size.Small)
            .addTopping(ToppingName.Cheese, ToppingPortion.RightHalf)
            .addTopping(ToppingName.Sauce, ToppingPortion.LeftHalf)
            .addTopping(ToppingName.GreenPepper, ToppingPortion.Full)
            .addTopping(ToppingName.Onion, ToppingPortion.Full)
            .addTopping(ToppingName.Jalapeno, ToppingPortion.LeftHalf)
            .build();
  }

  @Test
  public void testCost() {
    assertEquals(5.25, alacarte.cost(), 0.01);
  }

}