
/**
 * This class is an implementation of the "Money" interface, and is created by Yue Wen Peter Li.
 */
public class SimpleMoney implements Money {
  private int dollars;
  private int cents;
  /**
   * These two variable should keep recording the overall value of dollars and cents.
   */
  public static int TOTAL_DOLLARS;
  public static int TOTAL_CENTS;

  /**
   * The constructor with two parameters, and these two parameters should not be negative.
   */
  public SimpleMoney(int dollars, int cents) throws IllegalArgumentException {
    if (dollars < 0 || cents < 0) {
      throw new IllegalArgumentException("dollars and cents must be integer and strictly bigger "
              + "than 0");
    } else {
      this.cents = cents % 100;
      int carry = cents / 100;
      this.dollars = dollars + carry;
      TOTAL_DOLLARS = dollars;
      TOTAL_CENTS = cents;
    }
  }

  /**
   * This method could be called to add the other Money object's value into the origin one.
   */
  @Override
  public Money add(Money other) {
    other.add(this.dollars, this.cents);
    this.cents = TOTAL_CENTS % 100;
    int carry = TOTAL_CENTS / 100;
    this.dollars = TOTAL_DOLLARS + carry;
    return this;
  }

  /**
   * This method could be called by the Money add(Money other) function.
   * This method is useful for manipulating the origin money value.
   */
  @Override
  public Money add(int dollars, int cents) throws IllegalArgumentException {
    if (dollars < 0 || cents < 0) {
      throw new IllegalArgumentException("dollars and cents must be integer and strictly bigger "
              + "than 0");
    } else {
      this.dollars = this.dollars + dollars;
      TOTAL_DOLLARS = this.dollars;
      this.cents = this.cents + cents;
      TOTAL_CENTS = this.cents;
      return this;
    }
  }

  /**
   * This method simply return the value of money in decimal value.
   */
  @Override
  public Double getDecimalValue() {
    return ((double) TOTAL_DOLLARS + ((double) TOTAL_CENTS / 100));
  }

  /**
   * Return the value of money in the format of "$xx.yy",
   * and the decimal should be exactly two digits after the decimal point. If it is necessary,
   * the string of the decimal should be padded with zero.
   */
  @Override
  public String toString() {
    return String.format("%c%d.%02d", '$', this.dollars, this.cents);
  }
}