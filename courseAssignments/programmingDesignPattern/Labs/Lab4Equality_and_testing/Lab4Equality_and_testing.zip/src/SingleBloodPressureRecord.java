import java.util.Objects;

/**
 * This class implements the blood pressure device.
 * In order to compare two devices, this class also overrides the equal and hash function.
 */
public class SingleBloodPressureRecord implements BloodPressureRecord {
  private double sys;
  private double dias;
  private final String id;

  /**
   * This is the constructor for building a device record for one specific patient.
   *
   * @param id   the id of the patient.
   * @param sys  the systolic reading of the patient.
   * @param dias the diastolic reading of the patient.
   */
  public SingleBloodPressureRecord(String id, double sys, double dias)
          throws IllegalArgumentException {
    if (id.equals("")) {
      throw new IllegalArgumentException();
    }
    if (sys < 0 || dias < 0) {
      throw new IllegalArgumentException();
    }

    this.id = id;
    this.sys = sys;
    this.dias = dias;
  }

  /**
   * This method represents the id of the patient.
   *
   * @return the id of the patient.
   */
  @Override
  public String getID() {
    return id;
  }

  /**
   * This method represents the current systolic reading of the patient.
   *
   * @return the reading of systolic.
   */
  @Override
  public double getSystolicReading() {
    return sys;
  }

  /**
   * This method represents the current diastolic reading of the patient.
   *
   * @return the reading of diastolic.
   */
  @Override
  public double getDiastolicReading() {
    return dias;
  }

  /**
   * This method represents the update of the new reading of the systolic reading.
   *
   * @param sys the new systolic reading.
   * @throws IllegalArgumentException if the reading is smaller than diastolic.
   */
  @Override
  public void updateSystolicReading(double sys) throws IllegalArgumentException {
    if (sys < dias || sys < 0) {
      throw new IllegalArgumentException(
              "the systolic should be greater than diastolic");
    }
    this.sys = sys;
  }

  /**
   * This method represents the update of the new reading of the diastolic reading.
   *
   * @param dias the new diastolic reading.
   * @throws IllegalArgumentException of the reading is bigger than systolic.
   */
  @Override
  public void updateDiastolicReading(double dias) throws IllegalArgumentException {
    if (dias > sys || dias < 0) {
      throw new IllegalArgumentException(
              "the diastolic should be lesser than systolic");
    }
    this.dias = dias;
  }



  /*
  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || (getClass() != o.getClass())) {
      return false;
    }
    SingleBloodPressureRecord that = (SingleBloodPressureRecord) o;
    return (Double.compare(sys, that.sys) == 0 || Math.abs(sys - that.sys) < 1)
            && (Double.compare(dias, that.dias) == 0  || Math.abs(dias - that.dias) < 1)
            && Objects.equals(id, that.id);
  }
  */

  /*
  @Override
  public int hashCode() {
    return Objects.hash(id);
  }
  */

  /**
   * This method represent the comparison between the two objects.
   */
  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || (getClass() != o.getClass())) {
      return false;
    }
    SingleBloodPressureRecord that = (SingleBloodPressureRecord) o;
    return (Double.compare(sys, that.sys) == 0
            || Double.compare(sys, Math.ceil(that.sys)) == 0
            || Double.compare(sys, Math.floor(that.sys)) == 0
            && Double.compare(dias, that.dias) == 0
            || Double.compare(dias, Math.ceil(that.dias)) == 0
            || Double.compare(dias, Math.floor(that.dias)) == 0
            && Objects.equals(id, that.id));
  }

  /**
   * This method represent the hash function and hash code between the two objects.
   */
  @Override
  public int hashCode() {
    return Objects.hash(id);
  }
}


