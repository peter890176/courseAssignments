package betterpizza;

import java.util.Map;

import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

/**
 * This is the abstract pizza class to remove duplications.
 */
public abstract class PizzaBuilder<T> {
  protected Crust crust;
  protected Size size;
  protected Map<ToppingName, ToppingPortion> toppings;

  protected T returnBuilder() {
    return (T) this;
  }


}
