package betterpizza;

import java.util.HashMap;
import java.util.Map;

import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

/**
 * This class represents a vegetarian pizza.
 */
public class VeggiePizza extends AlaCartePizza {

  /**
   * This is the inner builder class for Veggie Pizza.
   */
  public static class VeggiePizzaBuilder extends PizzaBuilder<VeggiePizza.VeggiePizzaBuilder> {

    /**
     * This is the inner builder constructor for Veggie Pizza.
     */
    public VeggiePizzaBuilder() {
      new AlaCartePizza.AlaCartePizzaBuilder();
      this.toppings = new HashMap<>();
      this.toppings.put(ToppingName.Cheese, ToppingPortion.Full);
      this.toppings.put(ToppingName.Sauce, ToppingPortion.Full);
      this.toppings.put(ToppingName.BlackOlive, ToppingPortion.Full);
      this.toppings.put(ToppingName.GreenPepper, ToppingPortion.Full);
      this.toppings.put(ToppingName.Onion, ToppingPortion.Full);
      this.toppings.put(ToppingName.Jalapeno, ToppingPortion.Full);
      this.toppings.put(ToppingName.Tomato, ToppingPortion.Full);
    }

    protected VeggiePizzaBuilder returnBuilder() {
      return this;
    }

    public VeggiePizzaBuilder crust(Crust crust) {
      this.crust = crust;
      return returnBuilder();
    }

    public VeggiePizzaBuilder size(Size size) {
      this.size = size;
      return returnBuilder();
    }

    public VeggiePizzaBuilder addTopping(ToppingName name, ToppingPortion portion) {
      this.toppings.put(name, portion);
      return returnBuilder();
    }

    public VeggiePizzaBuilder removeTopping(ToppingName name) {
      this.toppings.remove(name);
      return returnBuilder();
    }

    public VeggiePizzaBuilder noJalapeno() {
      this.toppings.remove(ToppingName.Jalapeno);
      return returnBuilder();
    }

    public VeggiePizzaBuilder noCheese() {
      this.toppings.remove(ToppingName.Cheese);
      return returnBuilder();
    }

    public VeggiePizzaBuilder noSauce() {
      this.toppings.remove(ToppingName.Sauce);
      return returnBuilder();
    }

    public VeggiePizzaBuilder noBlackOlive() {
      this.toppings.remove(ToppingName.BlackOlive);
      return returnBuilder();
    }

    public VeggiePizzaBuilder noGreenPepper() {
      this.toppings.remove(ToppingName.GreenPepper);
      return returnBuilder();
    }

    public VeggiePizzaBuilder noOnion() {
      this.toppings.remove(ToppingName.Onion);
      return returnBuilder();
    }

    public VeggiePizzaBuilder noTomato() {
      this.toppings.remove(ToppingName.Tomato);
      return returnBuilder();
    }

    public VeggiePizza build() {
      return new VeggiePizza(size, crust, toppings);
    }
  }

  /**
   * Create a pizza given its crust type, size and toppings.
   */
  protected VeggiePizza(Size size, Crust crust, Map<ToppingName, ToppingPortion> toppings)
          throws IllegalStateException {
    super(size, crust, toppings);

  }
}
