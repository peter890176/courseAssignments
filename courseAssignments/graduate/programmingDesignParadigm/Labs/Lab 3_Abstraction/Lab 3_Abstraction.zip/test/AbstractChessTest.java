import org.junit.Before;

import static org.junit.Assert.assertEquals;

/**
 * This abstract test class is to reduce redundant methods and attributes, thus minimize the code.
 */
public abstract class AbstractChessTest {
  protected boolean[][] results;

  /**
   * This method is to set the empty grids.
   */
  @Before
  public void setup() {
    results = new boolean[8][8];
  }

  protected void verifyMoveResults(ChessPiece piece) {
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        if ((i == piece.getRow()) && (j == piece.getColumn())) {
          continue;
        }
        assertEquals("Piece at :" + piece.getRow() + "," + piece.getColumn() +
                        ", Unexpected canMove result "
                        + "for "
                        + "i=" + i + " j=" +
                        j + "",
                results[i][j], piece.canMove(i, j));
      }
    }
  }

  protected void initializeResults() {
    for (int row = 0; row < 8; row++) {
      for (int col = 0; col < 8; col++) {
        results[row][col] = false;
      }
    }
  }

}
