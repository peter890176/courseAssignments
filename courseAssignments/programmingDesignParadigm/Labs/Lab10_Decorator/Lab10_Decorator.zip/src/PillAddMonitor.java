import java.util.ArrayList;
import java.util.List;


/**
 * The decorator with Monitor method.
 */
public class PillAddMonitor extends PillDecorator {
  private List<Integer> addCounts;
  private int count;

  /**
   * The Constructor for monitor decorator.
   */
  public PillAddMonitor(PillCounter loggingPillCounter) {
    super(loggingPillCounter);
    addCounts = new ArrayList<>();
    count = 0;
  }

  @Override
  public void addPill(int count) {
    super.addPill(count);
    this.count = this.count + count;
  }

  @Override
  public void reset() {
    super.reset();
    addCounts.add(count);
    count = 0;
  }

  public List<Integer> getAddCounts() {
    return addCounts;
  }
}
