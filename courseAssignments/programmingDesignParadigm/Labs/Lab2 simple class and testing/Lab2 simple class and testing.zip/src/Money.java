
/**
 * This interface represents the US money and some related functions,
 * and is created by Yue Wen Peter Li.
 */
public interface Money {

  /**
   * This method should have only one parameter.
   * the method add two amounts of money.
   *
   * @param other represents the amount of the other money.
   * @return the object itself.
   */
  Money add(Money other);

  /**
   * This method should have two parameters.
   * The method add the money if the given money format was seperated into dollars and cents.
   *
   * @param dollars represents the US dollars, may not be negative.
   * @param cents   represents the US cents, may not be negative, can be over 99 cents.
   * @return the object itself.
   * @throws IllegalArgumentException if any argument of the provided parameter(money) is invalid.
   */
  Money add(int dollars, int cents) throws IllegalArgumentException;

  /**
   * Return the decimal value of the money in the specific format which is "xx.yy",
   * and the value for the cent unit should be padded if needed.
   *
   * @return the decimal value.
   */
  Double getDecimalValue();
}
