/**
 * The decorator with batchAdd method.
 */
public class PillBatchAddCounter extends LoggingPillCounter implements PillCounter {
  private int cumulativeNumber;

  /**
   * The Constructor of this batch_add decorator.
   */
  public PillBatchAddCounter(PillCounter loggingPillCounter) {
    super();
    cumulativeNumber = 0;
  }

  /**
   * Add the specific number of pills to this counter. This method
   * is general enough to work with machines with different pill-filling
   * capacities.
   *
   * @param count single count number.
   */
  @Override
  public void addPill(int count) {
    cumulativeNumber = cumulativeNumber + count;
  }

  /**
   * Remove a pill from this counter. This method is called in case
   * a malfunction in the hardware is detected and it dispenses too
   * many pills. Only one pill may be removed at a time.
   */
  @Override
  public void removePill() {
    super.removePill();
  }

  /**
   * Reset the counter to 0.
   */
  @Override
  public void reset() {
    super.reset();
    cumulativeNumber = 0;
  }

  /**
   * Return how many pills have been counted so far.
   *
   * @return
   */
  @Override
  public int getPillCount() {
    super.addPill(cumulativeNumber);
    super.reset();
    return cumulativeNumber;
  }
}
