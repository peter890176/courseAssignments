package solution;

import java.util.function.Consumer;

/**
 * This node represents an empty node in the binary search tree (i.e. the
 * leaves).
 */
public class BSTEmptyNode<T extends Comparable<T>> implements BSTNode<T> {

  /**
   * This method is to insert a data into empty node, so it should create new node.
   */
  @Override
  public BSTNode<T> insert(T data) {
    return new BSTElementNode(data, new BSTEmptyNode(), new BSTEmptyNode());
  }

  /**
   * This method is to find minimum of this subtree, so it should throw exception.
   */
  @Override
  public T minimum() throws NothingThereException {
    throw new NothingThereException("Tree does not have any data");
  }

  /**
   * This method is to find maximum of this subtree, so it should throw exception.
   */
  @Override
  public T maximum() throws NothingThereException {
    throw new NothingThereException("Tree does not have any data");
  }

  /**
   * This method is to find the data of this node, so it should return false.
   */
  @Override
  public boolean contains(T data) {
    return false;
  }

  /**
   * This method is to convert the data of this node, so it should return empty string.
   */
  @Override
  public String toString() {
    return "";
  }

  /**
   * This method is to traverse this subtree, so it should remain empty.
   */
  @Override
  public void preorder(Consumer<T> consumer) {
    /*
     * This method is to traverse this subtree, so it should remain empty.
     */
  }

  /**
   * This method is to traverse this subtree, so it should remain empty.
   */
  @Override
  public void postorder(Consumer<T> consumer) {
    /*
     * This method is to traverse this subtree, so it should remain empty.
     */
  }

  /**
   * This method is to copy this node, so it should return same empty node.
   */
  @Override
  public BSTNode<T> copy() {
    BSTNode<T> newEmptyNode = new BSTEmptyNode<T>();
    return newEmptyNode;
  }

  /**
   * This method is to check the sameness of the nodes.
   */
  @Override
  public boolean same(BSTNode<T> other) {
    return (other instanceof BSTEmptyNode);
  }
}
