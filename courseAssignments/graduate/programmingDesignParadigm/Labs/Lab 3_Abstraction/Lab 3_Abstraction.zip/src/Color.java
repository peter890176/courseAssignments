/**
 * This enum represents the colors of the chess pieces.
 */
public enum Color {
  WHITE, BLACK
}
