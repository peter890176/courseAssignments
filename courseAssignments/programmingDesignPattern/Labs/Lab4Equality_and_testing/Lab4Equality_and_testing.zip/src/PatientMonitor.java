import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a patient monitor. It monitors several records of blood pressure,
 * specifically to see how many of them are going into hypertensive crisis.
 */
public class PatientMonitor {
  private List<BloodPressureRecord> bpRecordList;


  public PatientMonitor() {
    this.bpRecordList = new ArrayList<BloodPressureRecord>();
  }

  /**
   * This method represents to add a new record for a patient.
   *
   * @param t represent the specific patient record.
   */
  public void add(BloodPressureRecord t) {
    bpRecordList.add(t);
  }

  /**
   * This method represents to remove the record for a patient.
   *
   * @param t represent the specific patient record.
   */
  public void remove(BloodPressureRecord t) {
    bpRecordList.remove(t);
  }

  /**
   * This method represents to return the number of all records.
   */
  public int getNumberOfRecords() {
    return bpRecordList.size();
  }

  /**
   * This method could warn the care provider that how many patients' blood pressure are unusual.
   */
  public boolean emergency() {
    int count = 0;
    for (BloodPressureRecord t : bpRecordList) {
      if ((t.getSystolicReading() > 180) || (t.getDiastolicReading() < 120)) {
        count += 1;
      }
    }
    return count > 1;
  }
}
