import org.junit.Before;
import org.junit.Test;

import betterpizza.CheesePizza;
import betterpizza.ObservablePizza;
import pizza.Crust;
import pizza.Size;


import static org.junit.Assert.assertEquals;

/**
 * This is the test class for Cheese Pizza.
 */
public class CheesePizzaTest {
  private ObservablePizza cheese;

  @Before
  public void setup() {
    cheese = new CheesePizza.CheesePizzaBuilder()
            .crust(Crust.Classic)
            .size(Size.Large)
            .build();
  }

  @Test
  public void testCost() {
    assertEquals(9.0, cheese.cost(), 0.01);
  }

}