/**
 * This class describes the attributes and functions of chess piece called Queen.
 * Many of the attributes and functions have already been defined in the AbstractChess class.
 */
public class Queen extends AbstractChess {

  /**
   * The position and color are given to the constructor in the abstract class.
   * It helps the construction of this Queen chess piece.
   *
   * @param row   represents the row location for the Queen.
   * @param col   represents the col location for the Queen.
   * @param color represents the of the chess piece.
   */
  public Queen(int row, int col, Color color) {
    super(row, col, color);
  }

  /**
   * This method is checking the location is available for the chess piece Queen, and return.
   *
   * @param row represents the row location for the next move.
   * @param col represents the col location for the next move.
   */
  @Override
  public boolean canMove(int row, int col) {
    if ((row < 0) || (col < 0) || (row >= 8) || (col >= 8)) {
      return false;
    }
    return ((this.row == row) || (this.col == col)
            || (Math.abs(this.row - row) == Math.abs(this.col - col)));
  }
}
