import org.junit.Before;
import org.junit.Test;

import betterpizza.ObservablePizza;
import betterpizza.VeggiePizza;
import pizza.Crust;
import pizza.Size;


import static org.junit.Assert.assertEquals;

/**
 * This is the test class for Veggie Pizza.
 */
public class VeggiePizzaTest {
  private ObservablePizza veggie;

  @Before
  public void setup() {
    veggie = new VeggiePizza.VeggiePizzaBuilder()
            .crust(Crust.Classic)
            .size(Size.Medium)
            .noCheese()
            .build();
  }

  @Test
  public void testCost() {
    assertEquals(9.5, veggie.cost(), 0.01);
  }

}