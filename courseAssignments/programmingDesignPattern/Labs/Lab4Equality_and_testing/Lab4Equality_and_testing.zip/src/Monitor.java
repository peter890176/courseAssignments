/**
 * This is the interface called Monitor.
 * It provides some basic operation for the monitor for patient to monitor their blood pressure.
 */
public interface Monitor {

  void add(BloodPressureRecord t);

  void remove(BloodPressureRecord t);

  int getNumberOfRecords();

  boolean emergency();
}
